
abstract class FFAppConstants {
  static const String entitlementName = 'Pro';
}
