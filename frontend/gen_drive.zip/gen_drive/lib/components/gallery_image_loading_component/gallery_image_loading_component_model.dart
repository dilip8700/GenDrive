import '/flutter_flow/flutter_flow_util.dart';
import 'gallery_image_loading_component_widget.dart'
    show GalleryImageLoadingComponentWidget;
import 'package:flutter/material.dart';

class GalleryImageLoadingComponentModel
    extends FlutterFlowModel<GalleryImageLoadingComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
