import '/flutter_flow/flutter_flow_util.dart';
import 'dream_brush_image_widget.dart' show DreamBrushImageWidget;
import 'package:flutter/material.dart';

class DreamBrushImageModel extends FlutterFlowModel<DreamBrushImageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
