import '/flutter_flow/flutter_flow_util.dart';
import 'album_list_loading_component_widget.dart'
    show AlbumListLoadingComponentWidget;
import 'package:flutter/material.dart';

class AlbumListLoadingComponentModel
    extends FlutterFlowModel<AlbumListLoadingComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
