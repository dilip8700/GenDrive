import '/flutter_flow/flutter_flow_util.dart';
import 'blank_album_widget.dart' show BlankAlbumWidget;
import 'package:flutter/material.dart';

class BlankAlbumModel extends FlutterFlowModel<BlankAlbumWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
