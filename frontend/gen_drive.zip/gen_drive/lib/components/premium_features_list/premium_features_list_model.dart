import '/flutter_flow/flutter_flow_util.dart';
import 'premium_features_list_widget.dart' show PremiumFeaturesListWidget;
import 'package:flutter/material.dart';

class PremiumFeaturesListModel
    extends FlutterFlowModel<PremiumFeaturesListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
