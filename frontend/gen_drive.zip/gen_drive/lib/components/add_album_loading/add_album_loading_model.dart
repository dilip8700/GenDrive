import '/flutter_flow/flutter_flow_util.dart';
import 'add_album_loading_widget.dart' show AddAlbumLoadingWidget;
import 'package:flutter/material.dart';

class AddAlbumLoadingModel extends FlutterFlowModel<AddAlbumLoadingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
