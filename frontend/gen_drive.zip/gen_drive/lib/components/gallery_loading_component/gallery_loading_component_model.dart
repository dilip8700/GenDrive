import '/flutter_flow/flutter_flow_util.dart';
import 'gallery_loading_component_widget.dart'
    show GalleryLoadingComponentWidget;
import 'package:flutter/material.dart';

class GalleryLoadingComponentModel
    extends FlutterFlowModel<GalleryLoadingComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
