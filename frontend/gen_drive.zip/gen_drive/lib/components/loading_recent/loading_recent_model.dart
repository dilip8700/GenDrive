import '/flutter_flow/flutter_flow_util.dart';
import 'loading_recent_widget.dart' show LoadingRecentWidget;
import 'package:flutter/material.dart';

class LoadingRecentModel extends FlutterFlowModel<LoadingRecentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
