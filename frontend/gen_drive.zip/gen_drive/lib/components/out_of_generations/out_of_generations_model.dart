import '/flutter_flow/flutter_flow_util.dart';
import 'out_of_generations_widget.dart' show OutOfGenerationsWidget;
import 'package:flutter/material.dart';

class OutOfGenerationsModel extends FlutterFlowModel<OutOfGenerationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
