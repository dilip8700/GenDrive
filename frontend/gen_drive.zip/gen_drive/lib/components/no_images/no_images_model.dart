import '/flutter_flow/flutter_flow_util.dart';
import 'no_images_widget.dart' show NoImagesWidget;
import 'package:flutter/material.dart';

class NoImagesModel extends FlutterFlowModel<NoImagesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
