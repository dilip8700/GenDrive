import '/flutter_flow/flutter_flow_util.dart';
import 'empty_gallery_widget.dart' show EmptyGalleryWidget;
import 'package:flutter/material.dart';

class EmptyGalleryModel extends FlutterFlowModel<EmptyGalleryWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
