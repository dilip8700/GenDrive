import '/flutter_flow/flutter_flow_util.dart';
import 'folder_options_widget.dart' show FolderOptionsWidget;
import 'package:flutter/material.dart';

class FolderOptionsModel extends FlutterFlowModel<FolderOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
