import '/flutter_flow/flutter_flow_util.dart';
import 'loading_styles_widget.dart' show LoadingStylesWidget;
import 'package:flutter/material.dart';

class LoadingStylesModel extends FlutterFlowModel<LoadingStylesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
