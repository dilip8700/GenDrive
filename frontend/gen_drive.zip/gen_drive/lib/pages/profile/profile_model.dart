import '/backend/backend.dart';
import '/components/light_dark_toggle/light_dark_toggle_widget.dart';
import '/components/navbar/navbar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'profile_widget.dart' show ProfileWidget;
import 'package:flutter/material.dart';

class ProfileModel extends FlutterFlowModel<ProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Firestore Query - Query a collection] action in Container widget.
  AdminRecord? adminDocument;
  // Model for navbar component.
  late NavbarModel navbarModel;
  // Model for lightDarkToggle component.
  late LightDarkToggleModel lightDarkToggleModel;

  @override
  void initState(BuildContext context) {
    navbarModel = createModel(context, () => NavbarModel());
    lightDarkToggleModel = createModel(context, () => LightDarkToggleModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    navbarModel.dispose();
    lightDarkToggleModel.dispose();
  }
}
