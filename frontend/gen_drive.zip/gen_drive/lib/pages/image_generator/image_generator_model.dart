import '/components/generations_remaining_text/generations_remaining_text_widget.dart';
import '/components/navbar/navbar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'image_generator_widget.dart' show ImageGeneratorWidget;
import 'package:flutter/material.dart';

class ImageGeneratorModel extends FlutterFlowModel<ImageGeneratorWidget> {
  ///  Local state fields for this page.

  String? imageStyle = '';

  String imageSize = '1024x1024';

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for imagePrompt widget.
  FocusNode? imagePromptFocusNode;
  TextEditingController? imagePromptTextController;
  String? Function(BuildContext, String?)? imagePromptTextControllerValidator;
  // Model for GenerationsRemainingText component.
  late GenerationsRemainingTextModel generationsRemainingTextModel;
  // Model for navbar component.
  late NavbarModel navbarModel;

  @override
  void initState(BuildContext context) {
    generationsRemainingTextModel =
        createModel(context, () => GenerationsRemainingTextModel());
    navbarModel = createModel(context, () => NavbarModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    imagePromptFocusNode?.dispose();
    imagePromptTextController?.dispose();

    generationsRemainingTextModel.dispose();
    navbarModel.dispose();
  }
}
