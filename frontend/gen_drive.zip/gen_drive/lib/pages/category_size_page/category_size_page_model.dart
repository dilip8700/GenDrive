import '/flutter_flow/flutter_flow_util.dart';
import 'category_size_page_widget.dart' show CategorySizePageWidget;
import 'package:flutter/material.dart';

class CategorySizePageModel extends FlutterFlowModel<CategorySizePageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  String currentPageLink = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
